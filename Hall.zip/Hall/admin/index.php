<?php include 'sidebar.php'?>



     
           
          
    <div id="wrapper">
         
        
      <div id="page-wrapper" >
          <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h2>welcome to admin panel</h2>
                    </div>
                </div>
                <!-- /. ROW  -->
                <hr />
   
                   
                   
                <!-- /. ROW  -->
    
                
            


                
                    

                <!-- /. ROW  -->
    
                 
                <!-- /. ROW  -->

            </div>
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
   

     <!-- /. WRAPPER  -->
      <?php include 'footer.php'?>
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
   
   

