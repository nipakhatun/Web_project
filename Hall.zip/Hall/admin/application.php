﻿<?php include 'sidebar.php'?>


     
           
          
    <div id="wrapper">
         
       
        <div id="page-wrapper" >
          <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Application Details Edit</h2>
                    </div>
                </div>
                <!-- /. ROW  -->
                <hr />
   
                   
                    <div class="col-lg-6 col-md-6">
                
                        <a href="applicants.php" class="btn btn-primary">Seat Applications</a>
                
                        <a href="seatexchangeapplicants.php" class="btn btn-success">Seat Exchange</a>
                        <a href="vacationinfo.php" class="btn btn-info">Vacation</a>
                        <a href="guestapplicants.php" class="btn btn-primary">Guest Holders</a>
                       

                    </div>

                
                <!-- /. ROW  -->
    
                
            


                
                    

                <!-- /. ROW  -->
    
                 
                <!-- /. ROW  -->

            </div>
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
    
          

     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
      <?php include 'footer.php'?>
   

