<?php include 'sidebar.php';?>
<?php include 'config/config.php';?>
<?php include 'lib/Database.php';?>
<?php
$db=new Database();
?>       
    <div id="wrapper">
        
        <!-- /. NAV SIDE  -->
      
      <div id="page-wrapper" >
          <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Message From Provost</h2>
                    </div>
                </div>
                <!-- /. ROW  -->
                <hr />             
                    <div class="col-lg-6 col-md-6">
                    
                        <a href="post.php" class="btn btn-primary">Add impotant notice</a>
                        <a href="postlist.php" class="btn btn-success">News List</a>
                        <a href="message.php" class="btn btn-success">Add Message</a>
                       
                    </div>
                    <br>
                    <br>
                    <div class="container-fluid">,
                    <form action="" method="post"> 
                     
                
                    <textarea class="ckeditor" name="message"></textarea>
                    <input type="submit" value="INSERT" name="insert">

              </form>

        
                       

                    </div>
                 <?php
if(isset($_POST['insert']) )
{
     $message=mysqli_real_escape_string($db->link, $_POST['message']);
     $query="INSERT INTO provost (message) VALUES('$message')";
    $result=$db->insert($query);
    if($result)
    {
        echo "<span style='color:red'>News inserted Successfully.</span>";
    }
    else 
    {
        echo "<span class='error'>News Not inserted !</span>";
    }
    
}

?>
      

      

            </div>
           
         <!-- /. PAGE WRAPPER  -->
        </div>
    
          

     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
     <?php include 'footer.php'?>

    <!-- <script src="assets/js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script> -->

    
   


