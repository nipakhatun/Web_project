﻿<?php include 'sidebar.php'?>
   
    <div id="wrapper">
         
       
      <div id="page-wrapper" >
          <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Students Details </h2>
                    </div>
                </div>
                <!-- /. ROW  -->
                <hr />
   
                   
                    <div class="col-lg-6 col-md-6">
                
                        <a href="residential.php" class="btn btn-primary">Residential</a>
                
                        <a href="nonresidential.php" class="btn btn-success">Non-Residential</a>
        
                       

                    </div>
                <!-- /. ROW  -->
    
                
            


                
                    

                <!-- /. ROW  -->
    
                 
                <!-- /. ROW  -->

            </div>
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
   
          

     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
     <?php include 'footer.php'?>
   

