<!DOCTYPE html>
<html>
<head>
<style type="text/css">
	.back{float: right;padding-right: 40px;}
	
</style>
	<title></title>
</head>
<body>
<div class="back">
<img src="back2.jpg" alt="back" style="height:80px; width="50px;" ">
	
</div>

</body>
</html>

